# JARVIS V1 — Personal AI Assistant

A real starter application with a futuristic web UI, configurable AI provider, persistent SQLite conversation history, and browser voice input/output.

## Requirements
- Python 3.10 or newer
- Internet connection for installing packages and using an online AI provider
- An API key from a provider compatible with the OpenAI chat-completions format (the example uses OpenRouter)

## Run on Windows
1. Extract this folder.
2. Open Command Prompt or PowerShell in this folder.
3. Create a virtual environment:
   ```powershell
   py -m venv .venv
   .\.venv\Scripts\activate
   ```
4. Install dependencies:
   ```powershell
   pip install -r requirements.txt
   ```
5. Copy `.env.example` to `.env`. Put your provider API key in `AI_API_KEY`, and select a model supported by your provider in `AI_MODEL`.
6. Start JARVIS:
   ```powershell
   uvicorn app:app --reload
   ```
7. Open http://127.0.0.1:8000 in your browser.

## Run on macOS/Linux
```bash
python3 -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
cp .env.example .env
# Edit .env and set AI_API_KEY and AI_MODEL
uvicorn app:app --reload
```

## Features
- Chat UI with a futuristic dark theme
- AI integration through configurable endpoint/model settings
- SQLite chat history across restarts
- Browser speech recognition and text-to-speech when supported
- Status endpoint at `/api/status`
- Clear conversation button
- No fake computer-control features

## Notes
- API usage may cost money; check your provider's pricing and free limits.
- Do not put your API key into the browser UI or commit `.env`.
- Browser voice input support varies by browser and operating system.
- This V1 does not control Windows, access files outside its workspace, or execute generated code. Those require separately designed and permission-checked tools.
