import os
import sqlite3
from datetime import datetime
from pathlib import Path
from typing import Optional

import httpx
from dotenv import load_dotenv
from fastapi import FastAPI, HTTPException
from fastapi.responses import HTMLResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel, Field

load_dotenv()
ROOT = Path(__file__).parent
DB_PATH = ROOT / "jarvis_memory.db"
app = FastAPI(title="JARVIS V1", version="1.0.0")
app.mount("/static", StaticFiles(directory=ROOT / "static"), name="static")

SYSTEM_PROMPT = """You are JARVIS, a helpful, capable personal AI assistant.
Be clear, practical, and honest. Do not claim to have run commands, changed files,
accessed devices, or completed actions unless a connected tool actually did so.
Help the user plan projects, write and explain code, and debug errors.
Ask before suggesting destructive changes. Never ask the user to paste API keys into chat."""

class ChatRequest(BaseModel):
    message: str = Field(min_length=1, max_length=12000)

class ChatResponse(BaseModel):
    reply: str
    configured: bool

def db():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn

def init_db():
    with db() as conn:
        conn.execute("""CREATE TABLE IF NOT EXISTS messages (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            role TEXT NOT NULL,
            content TEXT NOT NULL,
            created_at TEXT NOT NULL
        )""")

def save_message(role: str, content: str):
    with db() as conn:
        conn.execute("INSERT INTO messages(role, content, created_at) VALUES(?,?,?)",
                     (role, content, datetime.utcnow().isoformat(timespec="seconds")))

def recent_messages(limit=16):
    with db() as conn:
        rows = conn.execute("SELECT role, content FROM messages ORDER BY id DESC LIMIT ?", (limit,)).fetchall()
    return [{"role": row["role"], "content": row["content"]} for row in reversed(rows)]

@app.on_event("startup")
def startup():
    init_db()

@app.get("/", response_class=HTMLResponse)
def home():
    return (ROOT / "static" / "index.html").read_text(encoding="utf-8")

@app.get("/api/status")
def status():
    return {
        "app": "JARVIS V1",
        "ai_configured": bool(os.getenv("AI_API_KEY")),
        "model": os.getenv("AI_MODEL", "not configured"),
        "memory": "SQLite enabled",
        "voice": "Browser speech APIs (if supported)"
    }

@app.get("/api/history")
def history():
    with db() as conn:
        rows = conn.execute("SELECT role, content, created_at FROM messages ORDER BY id ASC LIMIT 200").fetchall()
    return [dict(row) for row in rows]

@app.delete("/api/history")
def clear_history():
    with db() as conn:
        conn.execute("DELETE FROM messages")
    return {"ok": True}

@app.post("/api/chat", response_model=ChatResponse)
async def chat(body: ChatRequest):
    message = body.message.strip()
    if not message:
        raise HTTPException(400, "Please enter a message.")
    save_message("user", message)

    api_key = os.getenv("AI_API_KEY", "").strip()
    if not api_key:
        reply = (
            "I'm online, but my AI brain isn't connected yet. Add your provider's API key "
            "to the AI_API_KEY setting in the .env file, then restart JARVIS. "
            "You can still explore the interface and saved conversation memory."
        )
        save_message("assistant", reply)
        return ChatResponse(reply=reply, configured=False)

    endpoint = os.getenv("AI_BASE_URL", "https://openrouter.ai/api/v1/chat/completions").strip()
    model = os.getenv("AI_MODEL", "openai/gpt-4o-mini").strip()
    msgs = [{"role": "system", "content": SYSTEM_PROMPT}] + recent_messages(16)
    payload = {"model": model, "messages": msgs, "temperature": 0.6}
    headers = {"Authorization": f"Bearer {api_key}", "Content-Type": "application/json"}
    if "openrouter.ai" in endpoint:
        headers["HTTP-Referer"] = "http://localhost:8000"
        headers["X-Title"] = "JARVIS V1"

    try:
        async with httpx.AsyncClient(timeout=60) as client:
            response = await client.post(endpoint, headers=headers, json=payload)
            response.raise_for_status()
            data = response.json()
        reply = data["choices"][0]["message"]["content"]
        if isinstance(reply, list):
            reply = "\n".join(part.get("text", "") for part in reply if isinstance(part, dict))
        reply = str(reply).strip() or "I received an empty response. Please try again."
    except httpx.TimeoutException:
        reply = "The AI provider took too long to respond. Please try again."
    except httpx.HTTPStatusError as exc:
        detail = exc.response.text[:500]
        reply = f"The AI provider returned HTTP {exc.response.status_code}. Check your model, API key, and provider limits.\n\nDetails: {detail}"
    except (KeyError, ValueError, httpx.HTTPError) as exc:
        reply = f"I couldn't reach the AI provider. Check your internet connection and .env settings. ({type(exc).__name__})"

    save_message("assistant", reply)
    return ChatResponse(reply=reply, configured=True)
