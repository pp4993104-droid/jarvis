const messagesEl=document.querySelector("#messages");
const form=document.querySelector("#chat-form");
const input=document.querySelector("#message-input");
const sendBtn=document.querySelector("#send-btn");
const micBtn=document.querySelector("#mic-btn");
let busy=false;
function addMessage(role,text){
  const welcome=messagesEl.querySelector(".welcome"); if(welcome) welcome.remove();
  const row=document.createElement("div"); row.className="message "+role;
  const avatar=document.createElement("div"); avatar.className="avatar"; avatar.textContent=role==="user"?"YOU":"J";
  const bubble=document.createElement("div"); bubble.className="bubble"; bubble.textContent=text;
  row.append(avatar,bubble); messagesEl.append(row); messagesEl.scrollTop=messagesEl.scrollHeight; return bubble;
}
async function sendMessage(text){
  text=(text||"").trim(); if(!text||busy)return;
  busy=true; sendBtn.disabled=true; input.value=""; addMessage("user",text);
  const bubble=addMessage("assistant","Thinking…");
  try{
    const res=await fetch("/api/chat",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({message:text})});
    const data=await res.json(); if(!res.ok)throw new Error(data.detail||"Request failed");
    bubble.textContent=data.reply;
    if ("speechSynthesis" in window) {
      window.speechSynthesis.cancel();
      const utterance = new SpeechSynthesisUtterance(data.reply);
      utterance.rate = 1;
      window.speechSynthesis.speak(utterance);
    }
  }catch(e){bubble.textContent="Connection error: "+e.message;}
  finally{busy=false;sendBtn.disabled=false;input.focus();messagesEl.scrollTop=messagesEl.scrollHeight;}
}
form.addEventListener("submit",e=>{e.preventDefault();sendMessage(input.value)});
input.addEventListener("keydown",e=>{if(e.key==="Enter"&&!e.shiftKey){e.preventDefault();form.requestSubmit()}});
document.querySelectorAll("[data-prompt]").forEach(b=>b.addEventListener("click",()=>{input.value=b.dataset.prompt;input.focus()}));
document.querySelector("#clear-btn").addEventListener("click",async()=>{
  if(!confirm("Delete the saved conversation history?"))return;
  const r=await fetch("/api/history",{method:"DELETE"}); if(r.ok){messagesEl.innerHTML='<div class="welcome"><div class="welcome-icon">✳</div><h3>Memory cleared.</h3><p>Start a fresh conversation whenever you are ready.</p></div>';}
});
async function initStatus(){
  try{
    const s=await (await fetch("/api/status")).json();
    document.querySelector("#system-status").textContent=s.ai_configured?"AI CONNECTED":"AI SETUP NEEDED";
    document.querySelector("#ai-status").textContent=s.ai_configured?s.model:"API key missing";
  }catch{document.querySelector("#system-status").textContent="OFFLINE";document.querySelector("#ai-status").textContent="Unavailable";}
  const hasVoice=("SpeechRecognition" in window)||("webkitSpeechRecognition" in window);
  document.querySelector("#voice-status").textContent=("speechSynthesis" in window&&hasVoice)?"Browser voice ready":"Text mode available";
}
initStatus();
(async function loadHistory(){
  try {
    const res = await fetch("/api/history");
    if (!res.ok) return;
    const history = await res.json();
    if (!history.length) return;
    messagesEl.innerHTML = "";
    history.forEach(item => addMessage(item.role === "user" ? "user" : "assistant", item.content));
  } catch {}
})();
const SpeechRecognition=window.SpeechRecognition||window.webkitSpeechRecognition;
if(SpeechRecognition){
  const recognition=new SpeechRecognition(); recognition.lang="en-US"; recognition.interimResults=false; recognition.maxAlternatives=1;
  recognition.onstart=()=>micBtn.classList.add("listening");
  recognition.onend=()=>micBtn.classList.remove("listening");
  recognition.onerror=()=>{micBtn.classList.remove("listening");};
  recognition.onresult=e=>{input.value=e.results[0][0].transcript;input.focus();};
  micBtn.addEventListener("click",()=>{try{recognition.start()}catch{}});
}else{micBtn.title="Speech recognition is not supported in this browser";micBtn.addEventListener("click",()=>alert("Speech recognition is not supported here. Try a supported browser, or type your message."));}
